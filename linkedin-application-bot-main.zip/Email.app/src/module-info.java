/**
 * 
 */
/**
 * 
 */
module Email.app {
}